import { TrainingTemplate } from './training-template.model';
import { Subject, Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { async } from 'q';

@Injectable()
export class TemplateService {

    public templateListChanged = new Subject();
    private templates: TrainingTemplate[] = [];

    constructor(private httpClient: HttpClient) {

    }

    getTemplates() {
        this.httpClient.get<TrainingTemplate[]>('https://d-training.firebaseio.com/templates.json')
        .subscribe(
            templates => {
                if(templates) {
                    this.templates = templates
                    this.templateListChanged.next(this.templates)
                }    
            }
        );
        return this.templates;
    };

    getTemplate(id: number): TrainingTemplate {
        const index = this.templates.findIndex(template => template.id === id);
        return this.templates[index]
    }

    addTemplate(title: string, desc: string) {
        this.templates.push(
            new TrainingTemplate(Math.floor(Math.random() * 10000) , title, desc, [])
        );
        this.updateTemplates();
    };

    updateTemplates(){
        this.httpClient.put('https://d-training.firebaseio.com/templates.json', this.templates)
        .subscribe(
            response => {
                this.templateListChanged.next(this.templates)}
        );
    }

    deleteTemplate(id: number) {
        let index: number = this.templates.findIndex(template => template.id === id);
        if (index > -1) {
            this.templates.splice(index, 1);
        }
    };
};