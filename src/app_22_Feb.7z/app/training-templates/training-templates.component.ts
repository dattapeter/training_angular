import { Component, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-training-templates',
  templateUrl: './training-templates.component.html',
  styles: []
})

export class TrainingTemplatesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
