import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-assignments',
  templateUrl: './assignments.component.html',
  styles: []
})
export class AssignmentsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
