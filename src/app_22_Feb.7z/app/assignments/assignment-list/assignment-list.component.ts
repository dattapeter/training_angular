import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-assignment-list',
  templateUrl: './assignment-list.component.html',
  styles: []
})
export class AssignmentListComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
