
export class Training {
    constructor(
        public topic: string,
        public duration: number
    ){}
}