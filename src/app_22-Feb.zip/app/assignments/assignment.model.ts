
export class Assignment {
    constructor(
        public id: number,
        public traineer: string,
        public templateId: number
    ){}
}